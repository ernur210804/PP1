#include <iostream>
using namespace std;
int main(){
    int a,b,y;
    cin>>a>>b;
    y=a+b;
    cout<<y;
}