#include <iostream>
#include <algorithm>
using namespace std;
int main(){
    string s1;
    cin>>s1;
    cout<<"Welcome"<<" "<<s1;
}