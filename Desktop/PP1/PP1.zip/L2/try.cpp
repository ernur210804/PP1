#include <bits/stdc++.h>
using namespace std;
int main(){
    int a = 10;
    a=sqrt(a);
    string s = "bunny";
    char c = 'b';
    bool b = false;
    int f;
    cin>>f;
    f=sin(f);
    cout<<a <<endl<<c<<endl<<b<<endl<<f;

}