#include <iostream>
#include <cmath>
using namespace std;
int main(){
    int a,b,c,d;
    cin>>a;
    if(a%4==0 || a%400==0){
        cout<<"YES";
    }
    else{
        cout<<"NO";
    }

  
}
