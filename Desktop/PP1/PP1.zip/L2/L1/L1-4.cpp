#include <iostream>
#include <cmath>

using namespace std;
int main(){
    int a,b;
    cin>>a;
    b=a%2;
    if (b!=0){
        cout<<"Super";
    
    }
    else {
        (a<=5);
        (a>=2);
        cout<<"Not super";
        
    }
   
    