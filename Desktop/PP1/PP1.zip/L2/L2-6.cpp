#include <iostream>
#include <cmath>
using namespace std;
int main(){
    int n,i,b;
    b=0;
    cin>>n;
 for(i=1;i<=n;i++){
    b=b+i;
    
    }
    cout<<b;

   
}