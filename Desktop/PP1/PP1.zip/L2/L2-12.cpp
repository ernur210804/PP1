#include <iostream>
#include <cmath>
using namespace std;
    int main(){
        int n,a;
        cin>>n;
        int arr[n];
        for(int i=0;pow(2,i)<=n;i++){
            
            a=pow(2,i);
            
            cout<<a<<" ";
 
        }
}