#include <iostream>
#include <cmath>
using namespace std;
int main(){
    int a,b;
    cin>>a;
    
    
    b=a%2;
    if(a == 0) {
        cout<<"None";
    
    }
   else if (b!=0){
       
       cout<<"Odd";
    
   }
   else {
       cout<<"Even";
   }
   
    
}