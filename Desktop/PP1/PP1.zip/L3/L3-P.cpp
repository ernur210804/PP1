#include <iostream>
#include <cmath>
using namespace std;
int main(){
    int x,b;
    float a;
    cin>>x;
    a=sqrt(x);
    b=sqrt(x);

    if(a==b){
        cout<<"yes";

    }
    else{
        cout<<"no";
    }
}