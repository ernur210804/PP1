#include <iostream>
#include <cmath>

using namespace std;
int main(){
    int n,a,c;
    cin>>n;
    a=0;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
        if(arr[i]>0){
            a++;
        }else{
            
        }
        
    }
    cout<<a;
}