#include <bits/stdc++.h>
using namespace std;
int main(){
    vector <int> a;
    //int n;
    //cin>>n;
    int b;
    while(cin){
        cin>>b;
        
        
        a.push_back(b);

    }

    for(int i=0;i<a.size();i++){
        cout<<a[i]<<' ';
    }


}