#include <bits/stdc++.h>
using namespace std;
int main(){
    int a;
   cin>>a;
  int c,n;
 a=(a%1000);
 a=(a/10);

  cout<<a;
} 
