#include <bits/stdc++.h>
using namespace std;
int f(int a,int b){
  int c=a+b;
  return c;
}
int main(){
    int a,b;
    cin>>a>>b;
    cout<<f(a,b);
}