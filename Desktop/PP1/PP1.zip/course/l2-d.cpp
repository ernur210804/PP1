#include <bits/stdc++.h>
using namespace std;
int main(){
    int n,m;
    cin>>n>>m;
    int f;
    f=ceil((n*2)/m);
    if(f==1){
        f=2;
    }
    cout<<f;
   
    

}