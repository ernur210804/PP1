#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,sum=0;
    while(cin>>a){
        if(a==0)
        break;
        sum+=a;
    }
    cout<<sum;
}