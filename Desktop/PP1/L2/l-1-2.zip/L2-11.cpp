#include <iostream>
#include <cmath>
using namespace std;
int main(){
    int n,a;
    cin>>n;
    for(int i=1;i*i<=n;i++){
         
         a=i*i;
        a<=n;
        cout<<a<<endl;
    }
        

        
 }
    
    
