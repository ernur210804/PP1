#include <iostream>
using namespace std;
int main(){
    int n,m,a,b,c;
    cin>>n>>m;
    a=m/100;
    b=m%10;
    c=a+b;
    cout<<n+c;
    
}